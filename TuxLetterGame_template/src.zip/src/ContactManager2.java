import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class ContactManager2 {

    private static class Mots {
        String name = "";
    }

    public static void main(String[] args) throws Exception {

        // Initialise une chaîne de caractère avec le chemin du fichier XML.
        // Attention : Les backslashes (\) du chemin Windows sont dédoublés
        // car dans une chaîne de caractères, le backslash est le caractère
        // d’échappement qui permet d’écrire des caractères spéciaux tels que
        // \r (carriage return), \n (line feed) ou \t (tab).
        String filename = "C:\\Users\\DELL\\OneDrive\\Bureau\\NetBeansProjects_A_Rendre\\TuxLetterGame_template\\src\\game\\dico.xml";

        // Crée un objet de type File avec le chemin du fichier XML.
        File xmlFile = new File(filename);

        // Charge les données des personnes qui se trouve dans le fichier XML
        // dans un objet de type List de Person et affecte une référence à cet
        // objet à la variable personList.
        List<Mots> motsList = loadPersonDataFromXml(xmlFile);

        // Affiche le résultat dans la sortie standard (System.out).
        printPersonList(System.out, motsList);
    }


    public static List<Mots> loadPersonDataFromXml(File file) throws Exception {

        // Crée un tableau dynamique.
        List<Mots> motsList= new ArrayList<Mots>();

        // Crée un objet Document qui représente les données du fichier XML
        // sous la forme d’une hiérarchie d’objets de type Node. Un objet de
        // type nœud peut représenter aussi bien un élément, qu’un nœud
        // de texte ou un attribut.
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(file);
        doc.getDocumentElement().normalize();


        // Recherche tous les elements <person>
        NodeList personNodeList = doc.getElementsByTagName("ns1:mot");


        // Pour chaque élément XML de la liste
        for (int i = 0; i < personNodeList.getLength(); i = i + 1) {
            Node node = personNodeList.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {

                // Récupère l'élément
                Element motElement = (Element)node;

                // Crée un nouvel objet de type Person
                Mots mot = new Mots();
                mot.name = motElement.getTextContent();
                // Ajoute la personne à la liste
                motsList.add(mot);

            }
        }
        // Renvoie la référence à l’objet personList
        return motsList;
    }


    private static void printPersonList(PrintStream out, List<Mots> motsList) {

        for (int i = 0; i < motsList.size(); i = i + 1) {
            Mots mot = motsList.get(i);
            printPerson(out, mot);
        }
    }


    private static void printPerson(PrintStream out, Mots mot) {

        out.printf(" %s\r\n",
                mot.name);
    }
}
