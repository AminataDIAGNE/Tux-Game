
package game;
/**
 *
 * @author diagneam
 */
public class Profil {

    private final String nom;
    private final String avatar;
    private final String dateNaissance;
    public final String fileProfilXML = "src/xml/data/xml/profil.xml";
    
   public Profil() {
        this.nom = "";
        this.avatar = "";
        this.dateNaissance = "";
   }
   }
