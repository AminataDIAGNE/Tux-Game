package game;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import test.ContactManager2;

/**
 *
 * @author diagneam
 */
public class Dico {

    private ArrayList<String> listeNiveau1;
    private ArrayList<String> listeNiveau2;
    private ArrayList<String> listeNiveau3;
    private ArrayList<String> listeNiveau4;
    private ArrayList<String> listeNiveau5;
    private String cheminFichierDico;

    public Dico(String cheminFichier) {
        this.cheminFichierDico = cheminFichier;
        listeNiveau1 = new ArrayList<String>();
        listeNiveau2 = new ArrayList<String>();
        listeNiveau3 = new ArrayList<String>();
        listeNiveau4 = new ArrayList<String>();
        listeNiveau5 = new ArrayList<String>();

    }

    public String getMotDepuisListeNiveau(int niveau) {
        switch (vérifieNiveau(niveau)) {
            case 1:
                return getMotDepuisListe(this.listeNiveau1);

            case 2:
                return getMotDepuisListe(this.listeNiveau2);
            case 3:
                return getMotDepuisListe(this.listeNiveau3);
            case 4:
                return getMotDepuisListe(this.listeNiveau4);
            case 5:
                return getMotDepuisListe(this.listeNiveau5);
            default:
        }
        return null;
    }

    public void ajouteMotADico(int niveau, String mot) {
        int level = vérifieNiveau(niveau);
        switch (level) {
            case 1:
                listeNiveau1.add(mot);
                break;
            case 2:
                listeNiveau2.add(mot);
                break;
            case 3:
                listeNiveau3.add(mot);
                break;
            case 4:
                listeNiveau4.add(mot);
                break;
            case 5:
                listeNiveau5.add(mot);
                break;
            default:
        }
    }

    public String getCheminFichierDico() {
        return cheminFichierDico;
    }

    private int vérifieNiveau(int niveau) {
        if ((niveau >= 1) && (niveau <= 5)) {
            return niveau;
        } else {
            return 1; //valeur par défaut du niveau
        }
    }

    public String getMotDepuisListe(ArrayList<String> list) {
        if (!list.isEmpty()) {
            // generation random numbers entre 0 et la taille de la list
            int rand = (int) (Math.random() * list.size() - 1) + 1;
            //System.out.println( rand + "-> "+ list.get(rand) );
            return list.get(rand);
        } //si liste vide return valeur par défaut
        else {
            return "ListeVide";
        }

    }

    public ArrayList<String> getList1() {
        return listeNiveau1;
    }

    public void lireDictionnaireDOM(String filename) throws SAXException, IOException, ParserConfigurationException, Exception {

        String s = filename;
        List<ContactManager2.Mots> motsList = ContactManager2.loadMotDataFromXml(new File(s));
        //ContactManager2.printPersonList(System.out, motsList);
        for (int i = 0; i < motsList.size(); i++) {
            if (motsList.get(i).getAttribute().equals("1")) {
                ajouteMotADico(1, motsList.get(i).getName());

            } else if (motsList.get(i).getAttribute().equals("2")) {
                ajouteMotADico(2, motsList.get(i).getName());
            } else if (motsList.get(i).getAttribute().equals("3")) {
                ajouteMotADico(3, motsList.get(i).getName());
            } else if (motsList.get(i).getAttribute().equals("4")) {
                ajouteMotADico(4, motsList.get(i).getName());
            } else if (motsList.get(i).getAttribute().equals("5")) {
                ajouteMotADico(5, motsList.get(i).getName());
            }
        }
    }

}
